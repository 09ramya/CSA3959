# Android-Location-Based-Alarm
In this app user can put latitude and longitude of position and can set alarm. When user will come in range of  16 feet of that position alarm will start ringing. 

